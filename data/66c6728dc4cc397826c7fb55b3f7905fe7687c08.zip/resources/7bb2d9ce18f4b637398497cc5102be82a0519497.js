'use strict';

var ENVIRONMENT_IS_NODE = typeof process == "object"
                       && typeof process.versions == "object"
                       && typeof process.versions.node == "string";

function ecore_get_api(Module) {

    const sizeOfPtr = 4; //32 bit
    const f32Sz = 4; //32 bit float

    const ecore_init = (APIKey, config_in_s) => {
        const APIKey_utf8 = Module.stringToUTF8OnStack(APIKey);
        const config_in_s_utf8 = Module.stringToUTF8OnStack(config_in_s);
        Module._ecore_init(APIKey_utf8, config_in_s_utf8);
    };

    const ecore_feed = (buffer, bufferSize, fs_input) => {
        const bufPtr = Module._malloc(bufferSize*f32Sz);
        Module.HEAPF32.set(buffer, bufPtr >> 2);
        Module._ecore_feed(bufPtr, bufferSize, fs_input);
        Module._free(bufPtr);
    }

    const ecore_feed_all = (buffer, bufferSize, fs_input) => {
        const bufPtr = Module._malloc(bufferSize*f32Sz);
        Module.HEAPF32.set(buffer, bufPtr >> 2);
        Module._ecore_feed_all(bufPtr, bufferSize, fs_input);
        Module._free(bufPtr);
    };

    const ecore_speakers_hungry = (bufferSize, fs_input) => {
        const bufPtr = Module._malloc(bufferSize*f32Sz);
        const bufPtrFloat32 = bufPtr >> 2;
        Module._ecore_speakers_hungry(bufPtr, bufferSize, fs_input);

        const buffer = new Float32Array(bufferSize);
        const bufInHeap = Module.HEAPF32.subarray(bufPtrFloat32, bufPtrFloat32 + bufferSize);
        buffer.set(bufInHeap);
        Module._free(bufPtr);

        return buffer;
    };

    const ecore_gen_trigger = (cfg_str, trigger) => {
        const memBuf = Module.wasmMemory.buffer;
        const ptr2PtrFloat = Module._malloc(sizeOfPtr);
        const ptr2PtrFloatAsArr = new Int32Array(memBuf, ptr2PtrFloat, 1);

        const cfg_str_utf8 = Module.stringToUTF8OnStack(cfg_str);
        const trigger_utf8 = Module.stringToUTF8OnStack(trigger);

        const sz = Module._ecore_gen_trigger(ptr2PtrFloat, cfg_str_utf8, trigger_utf8);
        const ptrFloat = ptr2PtrFloatAsArr[0]; 
        const ptrFloat32 = ptrFloat >> 2;
        const triggerWaveBuf = new Float32Array(sz);
        const triggerWaveBufInHeap = Module.HEAPF32.subarray(ptrFloat32, ptrFloat32 + sz);
        triggerWaveBuf.set(triggerWaveBufInHeap);

        Module._free(ptrFloat);
        Module._free(ptr2PtrFloat);
        return triggerWaveBuf;
    };

    const ecore_queue_trigger = (trigger) => {
        const trigger_utf8 = Module.stringToUTF8OnStack(trigger);
        Module._ecore_queue_trigger(trigger_utf8);
    };

    const ecore_set_receiver_callback = ( cb ) => {
        Module._wasm_wrapper_set_common_receiver_callback();
        if(ENVIRONMENT_IS_NODE) {
            global.current_receiver_callback = cb;
        } else {
            window.current_receiver_callback = cb;
        }
    };

    const ecore_deinit = Module._ecore_deinit;

    return {
        init:                  ecore_init,
        feed:                  ecore_feed,
        feed_all:              ecore_feed_all,
        speakers_hungry:       ecore_speakers_hungry,
        gen_trigger:           ecore_gen_trigger,
        queue_trigger:         ecore_queue_trigger,
        set_receiver_callback: ecore_set_receiver_callback,
        deinit:                ecore_deinit
    };
};


export default ecore_get_api;

